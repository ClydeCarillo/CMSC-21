// 2024-02183
// KARYLLE MIRZI BOLANDO
// CMSC 21 - E1
// Machine Problem 10.1
// May 16, 2025


#include <stdio.h>

struct Record {
    int account;
    char name[21];
    double balance;
};

typedef struct Record Record;

void writeRecords();
void listAllRecords();
void findRecordByAccount();

int main() {
    int choice;
    do {
        printf("\n1. Write Records\n2. List All Records\n3. Find Record by Account Number\n0. Exit\n? ");
        scanf("%d", &choice);

        switch (choice) {
            case 1:
                writeRecords();
                break;
            case 2:
                listAllRecords();
                break;
            case 3:
                findRecordByAccount();
                break;
            case 0:
                printf("Exiting...\n");
                break;
            default:
                printf("Invalid option!\n");
        }
    } while (choice != 0);

    return 0;
}

void writeRecords() {
    FILE* fp = fopen("data.bin", "rb+");
    if (!fp) {
        fp = fopen("data.bin", "wb+");
        if (!fp) {
            printf("Error opening file!\n");
            return;
        }
    }

    printf("Enter account number 1 - 100 (0 to exit)\n? ");
    Record r;
    scanf("%i", &r.account);

    while (r.account > 0 && r.account <= 100) {
        printf("Enter name and balance\n? ");
        scanf("%s %lf", r.name, &r.balance);

        fseek(fp, sizeof(Record) * (r.account - 1), SEEK_SET);
        fwrite(&r, sizeof(Record), 1, fp);

        printf("Enter account number 1 - 100 (0 to exit)\n? ");
        scanf("%i", &r.account);
    }

    fclose(fp);
}

void listAllRecords() {
    FILE* fp = fopen("data.bin", "rb");
    if (!fp) {
        printf("File not found!\n");
        return;
    }

    Record r;
    printf("\n%-20s %-15s %10s\n", "Account No.", "Name", "Balance");
    printf("-----------------------------------------------\n");
    while (fread(&r, sizeof(Record), 1, fp) == 1) {
        if (r.account != 0) {
            printf("%-20d %-15s %10.2lf\n", r.account, r.name, r.balance);
        }
    }

    fclose(fp);
}

void findRecordByAccount() {
    FILE* fp = fopen("data.bin", "rb");
    if (!fp) {
        printf("File not found!\n");
        return;
    }

    int accountNumber;
    printf("Enter account number to search (1 - 100):\n? ");
    scanf("%d", &accountNumber);

    if (accountNumber <= 0 || accountNumber > 100) {
        printf("Invalid account number!\n");
        fclose(fp);
        return;
    }

    Record r;
    fseek(fp, sizeof(Record) * (accountNumber - 1), SEEK_SET);

    if (fread(&r, sizeof(Record), 1, fp) == 1 && r.account != 0) {
        printf("Account No.: %d\nName: %s\nBalance: %.2lf\n", r.account, r.name, r.balance);
    } else {
        printf("Account not found!\n");
    }

    fclose(fp);
}